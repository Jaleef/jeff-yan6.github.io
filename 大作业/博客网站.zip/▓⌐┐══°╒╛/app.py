from datetime import date, datetime
from flask import Flask, render_template, redirect, url_for, request, flash
from werkzeug.utils import secure_filename
import os
from flask_sqlalchemy import SQLAlchemy
import uuid
import sys

# 创建 Flask 应用实例
app = Flask(__name__)

# 设置 Flask 应用的配置
app.config['SECRET_KEY'] = 'SECRET_PROJECT'

app.config['UPLOAD_FOLDER'] = 'static/images'

app.config['BLOG_UPLOAD_FOLDER'] = 'static/blogImg'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///myDB.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


# 创建 SQLAlchemy 实例
db = SQLAlchemy(app)

# 定义 Blog 数据模型
class Blog(db.Model):
    
    # 每篇博客的唯一id
    id = db.Column(db.Integer, 
                   primary_key=True, 
                   autoincrement=True
                   )
    
    # 博客的名称
    title = db.Column(db.String(255), 
                      index=True, 
                      unique=False, 
                      default="无标题"
                      )
    
    # 博客的内容, 用Text存储
    text = db.Column(db.Text, 
                     index=True, 
                     unique=False
                     )
    
    # 博客发布的时间
    date = db.Column(db.Date, 
                     index=True, 
                     unique=False
                     )
    
    # 博客的发布者
    uploader = db.Column(db.String(10), 
                         index=True, 
                         unique=False, 
                         default="匿名"
                         )


# 检查数据库文件是否存在，如果存在则删除
if os.path.exists("instance/myDB.db"):
    os.remove("instance/myDB.db")


# 在 Flask 应用上下文中创建所有的数据库表
with app.app_context():
    
    db.create_all()

    # 创建三个 Blog 对象并添加到数据库会话中
    post1 = Blog(id=1, 
                 title="这是用来测试的文章2", 
                 text="## 这是文章内容", 
                 date=datetime.strptime("2024-06-15", "%Y-%m-%d"), 
                 uploader="xxx"
                 )
    
    db.session.add(post1)
    
    post2 = Blog(id=2, 
                 title="这是用来测试的文章2", 
                 text="## 这是文章内容", 
                 date=datetime.strptime("2024-06-15", "%Y-%m-%d"), 
                 uploader="xxx"
                 )
    
    db.session.add(post2)
    
    post3 = Blog(id=3, 
                 title="这是用来测试的文章3", 
                 text="## 这是文章内容", 
                 date=datetime.strptime("2024-06-15", "%Y-%m-%d"), 
                 uploader="xxx"
                 )
    
    db.session.add(post3)


    # 提交数据库会话
    db.session.commit()



# 定义路由和根视图函数
@app.route('/')
def index():
    
    return render_template("index.html", 
                           PageName="主页"
                           )

# 定义home的路由和渲染函数
@app.route('/home')
def home():
    
    # 查询所有的 Blog 对象并按日期降序排序
    posts = Blog.query.order_by(Blog.date.desc()).all()
    
    return render_template("home.html", 
                           PageName="主页", 
                           posts=posts
                           )


# 批量渲染博客文章
@app.route('/home/<int:post_id>')
def post(post_id):
    
    # 根据 id 查询 Blog 对象，如果不存在则返回 404 错误
    post = Blog.query.get_or_404(post_id)
    
    return render_template("post.html", 
                           PageName="Blog", 
                           post=post
                           )

# 写博客的页面渲染函数
@app.route('/home/editor', 
           methods=['GET', 'POST']
           )
def edit_post():
    
    # 发get请求, 写博客
    if request.method == 'GET':
        
        return render_template("editor.html", 
                               PageName="Markdown"
                               )
    
    # 发post请求, 提交博客
    if request.method == 'POST':
        
        # 文章名
        title = request.form.get('title')
        
        # 文章内容
        text = request.form.get('text')
        
        # 上传者
        uploader = request.form.get('uploader')
        
        # 提交日期
        load_date = date.today()

        # 检查标题是否存在
        if not title:
            
            flash("请一定输入标题！", 'error')
            
            return redirect(url_for('edit_post'))

        # 创建新的 Blog 对象并添加到数据库会话中
        post = Blog(title=title, 
                    
                    text=text, 
                    
                    date=load_date, 
                    
                    uploader=uploader
                    )
        
        db.session.add(post)

        try:
            
            # 提交数据库会话
            db.session.commit()
            
        except:
            
            # 如果提交失败则回滚数据库会话
            
            db.session.rollback()
            
        return redirect(url_for('home'))


# 写博客是上传图片的逻辑函数
@app.route('/home/editor/imgUpload', 
           methods=['POST']
           )
def imgUpload():
    
    try:
        
        # 获取上传的文件
        photo = request.files.get('editormd-image-file')
        
        photo_name = secure_filename(photo.filename)
        
        # 图片的拓展
        ext = photo_name.rsplit('.')[-1]

        # 生成一个新的文件名
        new_name = str(uuid.uuid4()) + "." + ext
        
        photo_path = os.path.join(app.config["BLOG_UPLOAD_FOLDER"], new_name)

        # 保存文件
        photo.save(photo_path)

        return {
            'success': 1,
            
            'message': '上传成功!',
            
            'url': "/" + photo_path
            
        }
        
    except Exception:
        # 发生异常
        
        return {
            'success': 0,
            
            'message': '上传失败'
            
        }


# 定义错误处理器
# 错误码404
@app.errorhandler(404)
def page_not_found(e):
    
    return render_template("404.html"), 404


# 错误码500
@app.errorhandler(500)
def internal_server_error(e):
    
    return render_template("404.html"), 500


# 主程序入口
if __name__ == "__main__":
    
    # 先检查一下参数
    if len(sys.argv) > 1:
        
        print("错误地传递了过多的参数")
        
        print(sys.argv)
        
    else:
        
        # 检查是否是python文件
        fileName = sys.argv[0].split(".")
        
        ext = fileName[-1]
        
        # 是python文件
        if ext == "py":
            
            # 启动 Flask 应用
            app.run()
        
        else:
            print("传入的不是python文件")